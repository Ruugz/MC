# Magic Chess: Go Go - AI Co-Pilot Analyzer

Aplikasi co-pilot untuk Magic Chess: Go Go.
TIDAK melakukan auto-click, bot, atau modifikasi game.

## Build
./gradlew assembleDebug
