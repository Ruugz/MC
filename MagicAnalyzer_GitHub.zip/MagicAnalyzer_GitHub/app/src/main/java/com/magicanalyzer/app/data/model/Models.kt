package com.magicanalyzer.app.data.model
data class Hero(val name:String,val tier:Int,val star:Int,val synergy:List<String>,val items:List<String>,val position:String,val role:String)
data class Synergy(val name:String,val active:Int,val required:Int,val description:String)
data class PlayerState(val gold:Int,val hp:Int,val level:Int,val exp:Int,val round:Int,val rank:Int,val interest:Int,val streak:Int)
data class ShopItem(val heroName:String,val cost:Int,val synergy:List<String>)
data class BoardState(val heroes:List<Hero>,val bench:List<Hero>,val synergies:List<Synergy>,val shop:List<ShopItem>,val player:PlayerState,val opponents:List<OpponentState>,val detectedAt:Long=System.currentTimeMillis())
data class OpponentState(val name:String,val hp:Int,val level:Int,val gold:Int,val composition:String,val strength:String)
data class Recommendation(val type:RecommendationType,val title:String,val description:String,val reason:String,val risk:String,val confidence:Int,val alternatives:List<String>)
enum class RecommendationType{BUY,SELL,KEEP,REROLL,LEVEL_UP,ITEM,SYNERGY,POSITION,COUNTER,PREDICTION}
data class AnalysisResult(val board:BoardState,val bestAction:Recommendation,val recommendations:List<Recommendation>,val compositionAnalysis:String,val strengthScore:Int,val prediction:String,val sufficientData:Boolean,val timestamp:Long=System.currentTimeMillis())