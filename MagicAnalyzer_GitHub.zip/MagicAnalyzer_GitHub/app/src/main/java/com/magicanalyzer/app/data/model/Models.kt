package com.magicanalyzer.app.data.model

data class Hero(
    val name: String,
    val cost: Int,
    val faction: String,
    val role: String,
    val star: Int = 1,
    val items: List<String> = emptyList(),
    val position: String = "bench"
)

data class Synergy(
    val name: String,
    val type: SynergyType,
    val active: Int,
    val required: Int,
    val bonus: String
)

enum class SynergyType { FACTION, ROLE }

data class PlayerState(
    val gold: Int,
    val hp: Int,
    val level: Int,
    val exp: Int,
    val expToNext: Int,
    val round: String,
    val rank: Int,
    val interest: Int,
    val streak: Int
)

data class ShopItem(val heroName: String, val cost: Int, val faction: String, val role: String)

data class OpponentState(
    val name: String,
    val hp: Int,
    val level: Int,
    val gold: Int,
    val composition: String,
    val strength: String
)

data class BoardState(
    val heroes: List<Hero>,
    val bench: List<Hero>,
    val shop: List<ShopItem>,
    val synergies: List<Synergy>,
    val player: PlayerState,
    val opponents: List<OpponentState>,
    val detectedAt: Long = System.currentTimeMillis()
)

enum class RecommendationType {
    BUY, SELL, KEEP, REROLL, LEVEL_UP, ITEM, SYNERGY, POSITION, COUNTER, PREDICTION
}

data class Recommendation(
    val type: RecommendationType,
    val title: String,
    val description: String,
    val reason: String,
    val risk: String,
    val confidence: Int,
    val alternatives: List<String>
)

data class AnalysisResult(
    val board: BoardState,
    val bestAction: Recommendation,
    val recommendations: List<Recommendation>,
    val compositionAnalysis: String,
    val strengthScore: Int,
    val prediction: String,
    val sufficientData: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
