package com.magicanalyzer.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
class MainActivity:AppCompatActivity(){
override fun onCreate(s:Bundle?){super.onCreate(s);setContentView(R.layout.activity_main)
val n=supportFragmentManager.findFragmentById(R.id.nav_host)as NavHostFragment
findViewById<BottomNavigationView>(R.id.bottom_nav).setupWithNavController(n.navController)}}