package com.magicanalyzer.app.data.repository
import com.magicanalyzer.app.data.local.*
import kotlinx.coroutines.flow.Flow
class HistoryRepository(private val d:HistoryDao){
fun getAll():Flow<List<HistoryEntity>>=d.getAll()
suspend fun insert(e:HistoryEntity):Long=d.insert(e)
suspend fun clear()=d.clear()}