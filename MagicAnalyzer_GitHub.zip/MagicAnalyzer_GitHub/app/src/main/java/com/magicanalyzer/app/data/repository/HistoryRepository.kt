package com.magicanalyzer.app.data.repository
import com.magicanalyzer.app.data.local.HistoryDao
import com.magicanalyzer.app.data.local.HistoryEntity
import kotlinx.coroutines.flow.Flow
class HistoryRepository(private val dao: HistoryDao) {
    fun getAll(): Flow<List<HistoryEntity>> = dao.getAll()
    suspend fun insert(entry: HistoryEntity): Long = dao.insert(entry)
    suspend fun clear() = dao.clear()
}
