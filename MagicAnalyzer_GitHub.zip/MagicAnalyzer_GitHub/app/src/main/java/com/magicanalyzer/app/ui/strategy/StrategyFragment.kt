package com.magicanalyzer.app.ui.strategy
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.data.model.Recommendation
import com.magicanalyzer.app.data.model.RecommendationType
import com.magicanalyzer.app.databinding.FragmentStrategyBinding
import com.magicanalyzer.app.databinding.ItemRecommendationBinding
class StrategyFragment : Fragment() {
    private var _binding: FragmentStrategyBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentStrategyBinding.inflate(inflater, container, false); return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as MagicApp
        val json = app.gameDataRepository.getLastAnalysis()
        if (json.isNullOrBlank()) { binding.tvEmpty.visibility = View.VISIBLE; return }
        binding.tvEmpty.visibility = View.GONE
        val map: Map<String, Any> = Gson().fromJson(json, object : TypeToken<Map<String, Any>>() {}.type)
        @Suppress("UNCHECKED_CAST")
        val recsRaw = map["recommendations"] as? List<Map<String, Any>> ?: emptyList()
        val recs = recsRaw.map { r -> Recommendation(
            type = RecommendationType.valueOf((r["type"] as? String) ?: "KEEP"),
            title = (r["title"] as? String).orEmpty(),
            description = (r["description"] as? String).orEmpty(),
            reason = (r["reason"] as? String).orEmpty(),
            risk = (r["risk"] as? String).orEmpty(),
            confidence = ((r["confidence"] as? Double)?.toInt()) ?: 50,
            alternatives = (r["alternatives"] as? List<String>) ?: emptyList()
        )}
        binding.tvComposition.text = (map["compositionAnalysis"] as? String).orEmpty()
        binding.tvPrediction.text = (map["prediction"] as? String).orEmpty()
        binding.tvStrength.text = "Strength: ${((map["strengthScore"] as? Double)?.toInt() ?: 0)}/100"
        binding.layoutRecs.removeAllViews()
        recs.forEach { rec ->
            val item = ItemRecommendationBinding.inflate(layoutInflater, binding.layoutRecs, true)
            item.tvTitle.text = rec.title; item.tvDesc.text = rec.description
            item.tvMeta.text = "${rec.type.name} • ${rec.confidence}% • ${rec.risk}"
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
