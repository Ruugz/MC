package com.magicanalyzer.app.ui.strategy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.databinding.FragmentStrategyBinding

class StrategyFragment : Fragment() {

    private var _binding: FragmentStrategyBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStrategyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as MagicApp
        val result = app.gameRepo.getLastAnalysis()?.takeIf { it.sufficientData }

        binding.tvEmpty.isVisible = result == null
        binding.tvComposition.isVisible = result != null
        binding.tvPrediction.isVisible = result != null
        if (result != null) {
            binding.tvComposition.text = result.compositionAnalysis
            binding.tvPrediction.text = result.prediction
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
