package com.magicanalyzer.app.ui.strategy
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.databinding.FragmentStrategyBinding
class StrategyFragment:Fragment(){
private var _b:FragmentStrategyBinding?=null;private val b get()=_b!!
override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{_b=FragmentStrategyBinding.inflate(i,c,false);return b.root}
override fun onViewCreated(v:View,s:Bundle?){super.onViewCreated(v,s)
val app=requireActivity().application as MagicApp
val j=app.gameRepo.getLastAnalysis()
if(j.isNullOrBlank()){b.tvEmpty.visibility=View.VISIBLE;return}
b.tvEmpty.visibility=View.GONE;b.tvComposition.text="Strategy loaded";b.tvPrediction.text="See analyzer for details"}
override fun onDestroyView(){super.onDestroyView();_b=null}}