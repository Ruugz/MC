package com.magicanalyzer.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.magicanalyzer.app.data.local.AppDatabase
import com.magicanalyzer.app.data.repository.GameDataRepository
import com.magicanalyzer.app.data.repository.HistoryRepository

class MagicApp : Application() {

    lateinit var historyRepo: HistoryRepository
        private set
    lateinit var gameRepo: GameDataRepository
        private set

    override fun onCreate() {
        super.onCreate()
        historyRepo = HistoryRepository(AppDatabase.getInstance(this).historyDao())
        gameRepo = GameDataRepository(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
    }
}
