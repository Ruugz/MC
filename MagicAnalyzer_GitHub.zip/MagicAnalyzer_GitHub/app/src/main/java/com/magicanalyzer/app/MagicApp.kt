package com.magicanalyzer.app
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.magicanalyzer.app.data.local.AppDatabase
import com.magicanalyzer.app.data.repository.GameDataRepository
import com.magicanalyzer.app.data.repository.HistoryRepository
class MagicApp : Application() {
    lateinit var database: AppDatabase; private set
    lateinit var historyRepository: HistoryRepository; private set
    lateinit var gameDataRepository: GameDataRepository; private set
    override fun onCreate() {
        super.onCreate(); instance = this
        database = AppDatabase.getInstance(this)
        historyRepository = HistoryRepository(database.historyDao())
        gameDataRepository = GameDataRepository(this)
        val ch = NotificationChannel(CHANNEL_OVERLAY, "Magic Analyzer Overlay", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
    companion object { const val CHANNEL_OVERLAY = "magic_overlay_channel"; lateinit var instance: MagicApp; private set }
}
