package com.magicanalyzer.app
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.magicanalyzer.app.data.local.AppDatabase
import com.magicanalyzer.app.data.repository.*
class MagicApp:Application(){
lateinit var db:AppDatabase;private set
lateinit var historyRepo:HistoryRepository;private set
lateinit var gameRepo:GameDataRepository;private set
override fun onCreate(){super.onCreate();instance=this
db=AppDatabase.getInstance(this);historyRepo=HistoryRepository(db.historyDao());gameRepo=GameDataRepository(this)
getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("overlay","Overlay",NotificationManager.IMPORTANCE_LOW))}
companion object{lateinit var instance:MagicApp;private set}}