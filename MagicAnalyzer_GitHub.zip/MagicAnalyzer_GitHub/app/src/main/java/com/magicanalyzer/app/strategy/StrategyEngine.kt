package com.magicanalyzer.app.strategy
import com.magicanalyzer.app.data.model.*
class StrategyEngine{
fun analyze(b:BoardState,suf:Boolean):AnalysisResult{
if(!suf)return AnalysisResult(b,Recommendation(RecommendationType.PREDICTION,"Data tidak cukup","","","",0,emptyList()),emptyList(),"",0,"",false)
val recs=mutableListOf<Recommendation>()
recs+=Recommendation(RecommendationType.BUY,"Beli hero synergy","Meningkatkan synergy","","",78,emptyList())
recs+=Recommendation(RecommendationType.LEVEL_UP,"Naik level","Ekonomi stabil","","",70,emptyList())
recs+=Recommendation(RecommendationType.ITEM,"Prioritaskan item carry","Damage carry","","",82,emptyList())
recs+=Recommendation(RecommendationType.POSITION,"Lindungi carry","Positioning benar","","",80,emptyList())
val best=recs.maxByOrNull{it.confidence}?:Recommendation(RecommendationType.KEEP,"Hold","","","",50,emptyList())
val score=(b.heroes.sumOf{it.star*10+it.tier*5}+b.heroes.sumOf{it.items.size*8}+b.synergies.sumOf{it.active*6}+b.player.level*3).coerceIn(0,100)
return AnalysisResult(b,best,recs,"Role: ${b.heroes.groupingBy{it.role}.eachCount()}",score,"Power spike",true)}}