package com.magicanalyzer.app.strategy
import com.magicanalyzer.app.data.model.*
class StrategyEngine{
fun analyze(b:BoardState,suf:Boolean):AnalysisResult{
if(!suf)return AnalysisResult(b,Recommendation(RecommendationType.PREDICTION,"Data tidak cukup","Screenshot tidak jelas. Coba foto ulang atau input manual.","Data tidak cukup.","Rekomendasi mungkin salah.",0, listOf("Foto ulang","Input manual")),emptyList(),"",0,"",false)
val recs=mutableListOf<Recommendation>()
recs+=analyzeShop(b);recs+=analyzeEconomy(b);recs+=analyzeSynergy(b);recs+=analyzePositioning(b);recs+=analyzeOpponents(b);recs+=predictNextRounds(b);recs+=analyzeBench(b)
val best=recs.maxByOrNull{it.confidence}?:Recommendation(RecommendationType.KEEP,"Hold","Tidak ada perubahan","","",50,emptyList())
val strength=computeStrength(b);val composition=describeComposition(b);val prediction=predictNextRounds(b).description
return AnalysisResult(b,best,recs,composition,strength,prediction,true)}
private fun analyzeShop(b:BoardState):Recommendation{
val syns=b.heroes.flatMap{listOf(it.faction,it.role)}.groupingBy{it}.eachCount()
val best=b.shop.maxByOrNull{val f=if(syns[it.faction]!=null)10 else 0;val r=if(syns[it.role]!=null)15 else 0;f+r}
return if(best!=null)Recommendation(RecommendationType.BUY,"Beli ${best.heroName} (${best.cost} gold)","Hero ini melengkapi synergy ${best.faction} atau ${best.role}","Meningkatkan power board","Gold berkurang ${best.cost}",85,listOf("Simpan gold","Reroll"))
else Recommendation(RecommendationType.KEEP,"Jangan beli hero","Tidak ada hero yang cocok","Hemat gold","Board tidak upgrade",70,listOf("Reroll","Level up"))}
private fun analyzeEconomy(b:BoardState):Recommendation{val g=b.player.gold;val l=b.player.level;val hp=b.player.hp;val i=g/10
return when{hp<30->Recommendation(RecommendationType.REROLL,"Reroll untuk upgrade star","HP kritis ($hp), butuh power spike","HP rendah = risiko eliminasi","Ekonomi rusak",80,listOf("Level up","Simpan gold"))
g>=10&&l<7->Recommendation(RecommendationType.LEVEL_UP,"Level Up ke ${l+1}","Gold cukup ($g), level up untuk slot unit","Slot bertambah = synergy lebih banyak","Gold berkurang 4",75,listOf("Reroll","Simpan gold"))
g>=20->Recommendation(RecommendationType.KEEP,"Simpan Gold","Ekonomi kuat, interest $i gold/round","Compound interest","Board tidak upgrade",65,listOf("Level up","Reroll"))
else->Recommendation(RecommendationType.KEEP,"Simpan Gold","Gold $g, tunggu interest 5+","Ekonomi prioritas","Board lemah sementara",60,listOf("Reroll","Level up"))}}
private fun analyzeSynergy(b:BoardState):Recommendation{val inc=b.synergies.filter{it.active<it.required}.sortedBy{it.required-it.active};val t=inc.firstOrNull()
return if(t!=null){val n=t.required-t.active;Recommendation(RecommendationType.SYNERGY,"Fokus ${t.name} (${t.active}/${t.required})","Butuh $n hero lagi untuk ${t.name}","Synergy lengkap = power spike","Mungkin perlu reroll",78,listOf("Flex synergy","Prioritaskan star upgrade"))}
else Recommendation(RecommendationType.KEEP,"Semua synergy aktif","Komposisi optimal","Tidak perlu perubahan","Mungkin upgrade tier",70,listOf("Upgrade synergy","Flex comp"))}
private fun analyzePositioning(b:BoardState):Recommendation{val hasTank=b.heroes.any{it.role=="Defender"||it.role=="Bruiser"};val hasCarry=b.heroes.any{it.role=="Marksman"||it.role=="Mage"}
return Recommendation(RecommendationType.POSITION,if(hasTank&&hasCarry)"Positioning sudah baik" else "Perbaiki positioning",if(hasTank&&hasCarry)"Tank di front, carry di back, assassin di flank" else if(!hasTank)"Tidak ada tank! Taruh unit tanky di front" else "Tidak ada carry! Prioritaskan damage di back","Positioning benar = unit survive","Assassin bisa lompat backline",82,listOf("Anti-assassin","Mirror lawan"))}
private fun analyzeOpponents(b:BoardState):Recommendation{val s=b.opponents.filter{it.hp>0}.maxByOrNull{when(it.strength){"Very High"->4;"High"->3;"Medium"->2;"Low"->1;else->0}}
return if(s!=null)Recommendation(RecommendationType.COUNTER,"Counter ${s.name}","Lawan terkuat: ${s.composition} (HP: ${s.hp})","Fokus counter untuk top 4","Counter bisa salah",72,listOf("Fokus top 4","All-in"))
else Recommendation(RecommendationType.KEEP,"Fokus board sendiri","Semua lawan lemah","Tidak perlu counter","Mungkin ada lawan tersembunyi",60,listOf("Optimize board","Prepare late game"))}
private fun predictNextRounds(b:BoardState):Recommendation{val r=b.player.round;val g=b.player.gold;val l=b.player.level
return Recommendation(RecommendationType.PREDICTION,"Round ${r}+1: ${if(g>15)"Level Up" else "Reroll"}","Target: ${if(l<6)"Level 6 + 6 unit" else "Upgrade star 2 carry"}","Ekonomi dan level mendukung","RNG shop bisa tidak mendukung",68,listOf("Slow roll","Fast 8","Hyper carry"))}
private fun analyzeBench(b:BoardState):Recommendation{val w=b.bench.filter{it.star==1&&it.cost<=2}
return if(w.isNotEmpty())Recommendation(RecommendationType.SELL,"Jual ${w.first().name}","Unit bench lemah tidak berguna","Bersihkan bench untuk ruang + gold","Kehilangan opsi flex",65,listOf("Simpan","Jual semua"))
else Recommendation(RecommendationType.KEEP,"Bench sudah bersih","Tidak ada unit lemah","Bench optimal","Mungkin simpan untuk upgrade",60,listOf("Beli unit baru","Upgrade bench"))}
private fun computeStrength(b:BoardState):Int{var s=b.heroes.sumOf{it.star*15}+b.synergies.sumOf{if(it.active>=it.required)it.required*10 else it.active*5}+b.player.level*5+(b.player.gold/10)*3+b.heroes.sumOf{it.items.size*8};return s.coerceIn(0,100)}
private fun describeComposition(b:BoardState):String{val f=b.heroes.groupingBy{it.faction}.eachCount();val r=b.heroes.groupingBy{it.role}.eachCount();val s=b.synergies.joinToString(", "){"${it.name} (${it.active}/${it.required})"};return "Faction: ${f.entries.joinToString{"${it.key} x${it.value}"}}
Role: ${r.entries.joinToString{"${it.key} x${it.value}"}}
Synergy: $s"}}