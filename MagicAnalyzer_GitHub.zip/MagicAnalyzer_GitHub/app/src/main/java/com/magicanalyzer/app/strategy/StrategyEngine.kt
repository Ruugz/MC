package com.magicanalyzer.app.strategy

import com.magicanalyzer.app.data.model.AnalysisResult
import com.magicanalyzer.app.data.model.BoardState
import com.magicanalyzer.app.data.model.Recommendation
import com.magicanalyzer.app.data.model.RecommendationType

class StrategyEngine {

    fun analyze(board: BoardState, sufficientData: Boolean): AnalysisResult {
        if (!sufficientData) {
            return AnalysisResult(
                board = board,
                bestAction = Recommendation(
                    RecommendationType.PREDICTION,
                    "Data tidak cukup",
                    "Screenshot tidak jelas. Coba foto ulang atau input manual.",
                    "Data tidak cukup.",
                    "Rekomendasi mungkin salah.",
                    0,
                    listOf("Foto ulang", "Input manual")
                ),
                recommendations = emptyList(),
                compositionAnalysis = "",
                strengthScore = 0,
                prediction = "",
                sufficientData = false
            )
        }

        val prediction = predictNextRounds(board)
        val recs = listOf(
            analyzeShop(board),
            analyzeEconomy(board),
            analyzeSynergy(board),
            analyzePositioning(board),
            analyzeOpponents(board),
            prediction,
            analyzeBench(board)
        )
        val best = recs.maxByOrNull { it.confidence }
            ?: Recommendation(RecommendationType.KEEP, "Hold", "Tidak ada perubahan", "", "", 50, emptyList())

        return AnalysisResult(
            board = board,
            bestAction = best,
            recommendations = recs,
            compositionAnalysis = describeComposition(board),
            strengthScore = computeStrength(board),
            prediction = prediction.description,
            sufficientData = true
        )
    }

    private fun analyzeShop(b: BoardState): Recommendation {
        val owned = b.heroes.flatMap { listOf(it.faction, it.role) }.toSet()
        fun score(faction: String, role: String) =
            (if (faction in owned) 10 else 0) + (if (role in owned) 15 else 0)

        val best = b.shop
            .maxByOrNull { score(it.faction, it.role) }
            ?.takeIf { score(it.faction, it.role) > 0 }

        return if (best != null) {
            Recommendation(
                RecommendationType.BUY,
                "Beli ${best.heroName} (${best.cost} gold)",
                "Hero ini melengkapi synergy ${best.faction} atau ${best.role}",
                "Meningkatkan power board",
                "Gold berkurang ${best.cost}",
                85,
                listOf("Simpan gold", "Reroll")
            )
        } else {
            Recommendation(
                RecommendationType.KEEP,
                "Jangan beli hero",
                "Tidak ada hero yang cocok",
                "Hemat gold",
                "Board tidak upgrade",
                70,
                listOf("Reroll", "Level up")
            )
        }
    }

    private fun analyzeEconomy(b: BoardState): Recommendation {
        val gold = b.player.gold
        val level = b.player.level
        val hp = b.player.hp
        val interest = gold / 10
        return when {
            hp < 30 -> Recommendation(
                RecommendationType.REROLL, "Reroll untuk upgrade star",
                "HP kritis ($hp), butuh power spike", "HP rendah = risiko eliminasi",
                "Ekonomi rusak", 80, listOf("Level up", "Simpan gold")
            )
            gold >= 10 && level < 7 -> Recommendation(
                RecommendationType.LEVEL_UP, "Level Up ke ${level + 1}",
                "Gold cukup ($gold), level up untuk slot unit", "Slot bertambah = synergy lebih banyak",
                "Gold berkurang 4", 75, listOf("Reroll", "Simpan gold")
            )
            gold >= 20 -> Recommendation(
                RecommendationType.KEEP, "Simpan Gold",
                "Ekonomi kuat, interest $interest gold/round", "Compound interest",
                "Board tidak upgrade", 65, listOf("Level up", "Reroll")
            )
            else -> Recommendation(
                RecommendationType.KEEP, "Simpan Gold",
                "Gold $gold, tunggu interest 5+", "Ekonomi prioritas",
                "Board lemah sementara", 60, listOf("Reroll", "Level up")
            )
        }
    }

    private fun analyzeSynergy(b: BoardState): Recommendation {
        val target = b.synergies
            .filter { it.active < it.required }
            .minByOrNull { it.required - it.active }
        return if (target != null) {
            val needed = target.required - target.active
            Recommendation(
                RecommendationType.SYNERGY,
                "Fokus ${target.name} (${target.active}/${target.required})",
                "Butuh $needed hero lagi untuk ${target.name}",
                "Synergy lengkap = power spike",
                "Mungkin perlu reroll",
                78,
                listOf("Flex synergy", "Prioritaskan star upgrade")
            )
        } else {
            Recommendation(
                RecommendationType.KEEP, "Semua synergy aktif", "Komposisi optimal",
                "Tidak perlu perubahan", "Mungkin upgrade tier", 70,
                listOf("Upgrade synergy", "Flex comp")
            )
        }
    }

    private fun analyzePositioning(b: BoardState): Recommendation {
        val hasTank = b.heroes.any { it.role == "Defender" || it.role == "Bruiser" }
        val hasCarry = b.heroes.any { it.role == "Marksman" || it.role == "Mage" }
        val good = hasTank && hasCarry
        return Recommendation(
            RecommendationType.POSITION,
            if (good) "Positioning sudah baik" else "Perbaiki positioning",
            when {
                good -> "Tank di front, carry di back, assassin di flank"
                !hasTank -> "Tidak ada tank! Taruh unit tanky di front"
                else -> "Tidak ada carry! Prioritaskan damage di back"
            },
            "Positioning benar = unit survive",
            "Assassin bisa lompat backline",
            82,
            listOf("Anti-assassin", "Mirror lawan")
        )
    }

    private fun analyzeOpponents(b: BoardState): Recommendation {
        val strongest = b.opponents
            .filter { it.hp > 0 }
            .maxByOrNull { strengthRank(it.strength) }
        return if (strongest != null) {
            Recommendation(
                RecommendationType.COUNTER,
                "Counter ${strongest.name}",
                "Lawan terkuat: ${strongest.composition} (HP: ${strongest.hp})",
                "Fokus counter untuk top 4",
                "Counter bisa salah",
                72,
                listOf("Fokus top 4", "All-in")
            )
        } else {
            Recommendation(
                RecommendationType.KEEP, "Fokus board sendiri", "Semua lawan lemah",
                "Tidak perlu counter", "Mungkin ada lawan tersembunyi", 60,
                listOf("Optimize board", "Prepare late game")
            )
        }
    }

    private fun strengthRank(label: String): Int = when (label) {
        "Very High" -> 4
        "High" -> 3
        "Medium" -> 2
        "Low" -> 1
        else -> 0
    }

    private fun predictNextRounds(b: BoardState): Recommendation {
        val round = b.player.round
        val gold = b.player.gold
        val level = b.player.level
        return Recommendation(
            RecommendationType.PREDICTION,
            "Round $round+1: ${if (gold > 15) "Level Up" else "Reroll"}",
            "Target: ${if (level < 6) "Level 6 + 6 unit" else "Upgrade star 2 carry"}",
            "Ekonomi dan level mendukung",
            "RNG shop bisa tidak mendukung",
            68,
            listOf("Slow roll", "Fast 8", "Hyper carry")
        )
    }

    private fun analyzeBench(b: BoardState): Recommendation {
        val weak = b.bench.filter { it.star == 1 && it.cost <= 2 }
        return if (weak.isNotEmpty()) {
            Recommendation(
                RecommendationType.SELL, "Jual ${weak.first().name}",
                "Unit bench lemah tidak berguna", "Bersihkan bench untuk ruang + gold",
                "Kehilangan opsi flex", 65, listOf("Simpan", "Jual semua")
            )
        } else {
            Recommendation(
                RecommendationType.KEEP, "Bench sudah bersih", "Tidak ada unit lemah",
                "Bench optimal", "Mungkin simpan untuk upgrade", 60,
                listOf("Beli unit baru", "Upgrade bench")
            )
        }
    }

    private fun computeStrength(b: BoardState): Int {
        val heroes = b.heroes.sumOf { it.star * 15 + it.items.size * 8 }
        val synergies = b.synergies.sumOf { if (it.active >= it.required) it.required * 10 else it.active * 5 }
        val player = b.player.level * 5 + (b.player.gold / 10) * 3
        return (heroes + synergies + player).coerceIn(0, 100)
    }

    private fun describeComposition(b: BoardState): String {
        val factions = b.heroes.groupingBy { it.faction }.eachCount()
            .entries.joinToString { "${it.key} x${it.value}" }
        val roles = b.heroes.groupingBy { it.role }.eachCount()
            .entries.joinToString { "${it.key} x${it.value}" }
        val synergies = b.synergies.joinToString(", ") { "${it.name} (${it.active}/${it.required})" }
        return "Faction: $factions\nRole: $roles\nSynergy: $synergies"
    }
}
