package com.magicanalyzer.app.strategy
import com.magicanalyzer.app.data.model.*
class StrategyEngine {
    fun analyze(board: BoardState, sufficientData: Boolean): AnalysisResult {
        if (!sufficientData) return AnalysisResult(
            board=board,
            bestAction = Recommendation(RecommendationType.PREDICTION,"Data tidak cukup","Sistem tidak dapat menganalisis data. Gunakan screenshot jelas atau input manual.","Data tidak cukup.","Rekomendasi mungkin tidak tepat.",0, listOf("Gunakan screenshot","Input manual")),
            recommendations=emptyList(), compositionAnalysis="Data tidak cukup", strengthScore=0, prediction="Data tidak cukup", sufficientData=false
        )
        val recs = mutableListOf<Recommendation>()
        val synCounts = board.heroes.flatMap { it.synergy }.groupingBy { it }.eachCount()
        val targetSyn = synCounts.maxByOrNull { it.value }?.key ?: "Abyss"
        recs += Recommendation(RecommendationType.BUY,"Beli hero synergy $targetSyn","Meningkatkan synergy $targetSyn.","Synergy aktif bisa di-upgrade.","Gold berkurang.",78, listOf("Simpan gold","Beli star upgrade"))
        recs += if (board.player.hp < 40) Recommendation(RecommendationType.REROLL,"Reroll untuk upgrade star","HP rendah, butuh unit star lebih tinggi.","HP ${board.player.hp} sangat rendah.","Ekonomi rusak.",72, listOf("Naik level","Slow roll"))
                else if (board.player.gold >= 10 && board.player.level < 8) Recommendation(RecommendationType.LEVEL_UP,"Naik ke level ${board.player.level+1}","Ekonomi stabil.","Gold ${board.player.gold} cukup.","Kehilangan interest.",70, listOf("Reroll","Simpan gold"))
                else Recommendation(RecommendationType.KEEP,"Simpan gold","Ekonomi baik.","Gold cukup untuk interest 5.","Kehilangan tempo.",65, listOf("Reroll kecil","Naik level"))
        val carry = board.heroes.firstOrNull { it.role == "carry" || it.role == "mage" }
        recs += Recommendation(RecommendationType.ITEM,"Prioritaskan item untuk ${carry?.name ?: "carry"}","Berikan item damage ke carry.","Carry tanpa item = damage rendah.","Komponen lama didapat.",82, listOf("Item tank","Item utility"))
        recs += Recommendation(RecommendationType.SYNERGY,"Fokus komposisi $targetSyn","Aktifkan synergy tier tinggi.","Synergy aktif memberi bonus signifikan.","Switch comp = rugi.",74, listOf("Flex comp","Hyper carry"))
        recs += Recommendation(RecommendationType.POSITION,"Lindungi carry di belakang","Tank di front, carry di back, assassin di flank.","Positioning benar = carry output damage.","Assassin bisa lompat backline.",80, listOf("Anti-assassin","Mirror lawan"))
        val strongest = board.opponents.maxByOrNull { if (it.strength=="Very High") 3 else if (it.strength=="High") 2 else if (it.strength=="Medium") 1 else 0 }
        recs += Recommendation(RecommendationType.COUNTER,"Counter ${strongest?.name ?: "lawan terkuat"}","Lawan menggunakan ${strongest?.composition ?: "comp kuat"}.","Lawan ini kemungkinan final opponent.","Counter bisa salah.",68, listOf("Fokus top 4","All-in"))
        recs += Recommendation(RecommendationType.PREDICTION,"Round ${board.player.round+1}-${board.player.round+3}: Power spike","Target upgrade star 2 carry + 1 tank.","Ekonomi dan level mendukung.","RNG shop tidak mendukung.",66, listOf("Slow roll","Fast 8"))
        val weak = board.bench.firstOrNull { it.star == 1 && it.tier <= 2 }
        recs += Recommendation(RecommendationType.SELL,"Jual ${weak?.name ?: "unit bench lemah"}","Bersihkan bench.","Unit star 1 tier rendah tidak berguna.","Kehilangan opsi flex.",60, listOf("Simpan","Jual semua"))
        val best = recs.maxByOrNull { it.confidence } ?: Recommendation(RecommendationType.KEEP,"Hold","Tidak ada perubahan","","",50, emptyList())
        var score = board.heroes.sumOf { it.star*10 + it.tier*5 } + board.heroes.sumOf { it.items.size*8 } + board.synergies.sumOf { it.active*6 } + board.player.level*3
        score = score.coerceIn(0,100)
        val roles = board.heroes.groupingBy { it.role }.eachCount()
        val syn = board.synergies.joinToString(", ") { "${it.name} (${it.active}/${it.required})" }
        val composition = "Role: ${roles.entries.joinToString { "${it.key} x${it.value}" }} | Synergy: $syn"
        val prediction = "Round ${board.player.round+1}: ${if (board.player.gold>20) "Naik level" else "Reroll"} | Round ${board.player.round+2}: Upgrade star 2 | Round ${board.player.round+3}: Power spike"
        return AnalysisResult(board=board, bestAction=best, recommendations=recs, compositionAnalysis=composition, strengthScore=score, prediction=prediction, sufficientData=true)
    }
}
