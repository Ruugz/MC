package com.magicanalyzer.app.data.repository
import android.content.Context
class GameDataRepository(c:Context){
private val p=c.getSharedPreferences("g",Context.MODE_PRIVATE)
fun saveLastAnalysis(j:String){p.edit().putString("last",j).apply()}
fun getLastAnalysis():String?=p.getString("last",null)}