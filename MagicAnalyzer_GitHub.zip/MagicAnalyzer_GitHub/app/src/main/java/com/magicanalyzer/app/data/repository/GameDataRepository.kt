package com.magicanalyzer.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.magicanalyzer.app.data.model.AnalysisResult

class GameDataRepository(context: Context) {

    private val prefs = context.getSharedPreferences("g", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveLastAnalysis(result: AnalysisResult) {
        prefs.edit().putString(KEY_LAST, gson.toJson(result)).apply()
    }

    fun getLastAnalysis(): AnalysisResult? {
        val json = prefs.getString(KEY_LAST, null)?.takeIf { it.isNotBlank() } ?: return null
        return runCatching { gson.fromJson(json, AnalysisResult::class.java) }.getOrNull()
    }

    private companion object {
        const val KEY_LAST = "last"
    }
}
