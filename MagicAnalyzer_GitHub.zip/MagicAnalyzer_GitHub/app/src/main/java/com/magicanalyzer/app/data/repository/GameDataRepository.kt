package com.magicanalyzer.app.data.repository
import android.content.Context
class GameDataRepository(context: Context) {
    private val prefs = context.getSharedPreferences("game_data", Context.MODE_PRIVATE)
    fun saveLastAnalysis(json: String) { prefs.edit().putString("last_analysis", json).apply() }
    fun getLastAnalysis(): String? = prefs.getString("last_analysis", null)
}
