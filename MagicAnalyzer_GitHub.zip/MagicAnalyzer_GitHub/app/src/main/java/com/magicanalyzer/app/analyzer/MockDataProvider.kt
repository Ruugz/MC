package com.magicanalyzer.app.analyzer
import com.magicanalyzer.app.data.model.*
object MockDataProvider{
fun sampleBoard():BoardState=BoardState(
heroes=listOf(Hero("Tigreal",2,2,listOf("Tank","Cadia"),listOf("Helm"),"front","tank"),Hero("Alucard",3,2,listOf("Fighter","Abyss"),listOf("Axe"),"mid","fighter"),Hero("Miya",1,3,listOf("Marksman","Cadence"),listOf("Staff"),"back","carry")),
bench=emptyList(),synergies=listOf(Synergy("Abyss",2,2,"+15%Atk")),
shop=listOf(ShopItem("Layla",1,listOf("Marksman"))),
player=PlayerState(28,74,6,4,18,3,5,2),
opponents=listOf(OpponentState("P2",88,6,22,"Assassin","High")))}