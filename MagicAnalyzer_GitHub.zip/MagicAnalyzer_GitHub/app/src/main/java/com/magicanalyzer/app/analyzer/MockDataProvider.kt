package com.magicanalyzer.app.analyzer
import com.magicanalyzer.app.data.model.*
object MockDataProvider {
    fun sampleBoard(): BoardState = BoardState(
        heroes = listOf(
            Hero("Tigreal", 2, 2, listOf("Tank","Cadia"), listOf("Guardian Helm"), "front", "tank"),
            Hero("Alucard", 3, 2, listOf("Fighter","Abyss"), listOf("War Axe"), "mid", "fighter"),
            Hero("Miya", 1, 3, listOf("Marksman","Cadence"), listOf("Golden Staff"), "back", "carry"),
            Hero("Aurora", 4, 1, listOf("Mage","Frost"), emptyList(), "back", "mage"),
            Hero("Helcurt", 3, 1, listOf("Assassin","Abyss"), emptyList(), "mid", "assassin")
        ),
        bench = listOf(Hero("Balmond", 2, 1, listOf("Fighter","Lycan"), emptyList(), "bench", "fighter")),
        synergies = listOf(Synergy("Abyss",2,2,"+15% Attack"), Synergy("Cadia",2,2,"+10% Armor"), Synergy("Frost",1,3,"Slow")),
        shop = listOf(ShopItem("Layla",1,listOf("Marksman","Cadia")), ShopItem("Kagura",4,listOf("Mage","Onmyoji"))),
        player = PlayerState(gold=28, hp=74, level=6, exp=4, round=18, rank=3, interest=5, streak=2),
        opponents = listOf(
            OpponentState("Player2",88,6,22,"Assassin Burst","High"),
            OpponentState("Player7",92,7,35,"Tank+Marksman","Very High")
        )
    )
}
