package com.magicanalyzer.app.analyzer
import com.magicanalyzer.app.data.model.*
object MockDataProvider{
val heroDatabase=listOf(
Hero("Paquito",3,"Dragon Altar","Bruiser"),Hero("Roger",3,"SPECTRE","Bruiser"),Hero("Yu Zhong",4,"Dragoncaller","Bruiser"),Hero("Aldous",3,"Kishin","Bruiser"),Hero("Terizla",2,"Enchanted Tales","Bruiser"),Hero("Belerick",2,"Mistbender","Bruiser"),
Hero("Tigreal",2,"Shadeweaver","Defender"),Hero("Minotaur",2,"Astro Power","Defender"),Hero("Franco",3,"Echomancer","Defender"),Hero("Grock",4,"Dragon Altar","Defender"),Hero("Mathilda",3,"Starbelle","Defender"),Hero("Hylos",2,"Enchanted Tales","Defender"),
Hero("Carmilla",2,"Astro Power","Dauntless"),Hero("Esmeralda",3,"SPECTRE","Dauntless"),Hero("Ruby",3,"Starbelle","Dauntless"),Hero("Uranus",2,"Mistbender","Dauntless"),Hero("Barats",1,"Kishin","Dauntless"),
Hero("Zilong",2,"Astro Power","Weapon Master"),Hero("Martis",3,"Echomancer","Weapon Master"),Hero("Chou",3,"Starbelle","Weapon Master"),
Hero("Brody",2,"Shadeweaver","Marksman"),Hero("Beatrix",3,"Astro Power","Marksman"),Hero("Wanwan",3,"Dragon Altar","Marksman"),Hero("Clint",2,"SPECTRE","Marksman"),Hero("Miya",2,"Starbelle","Marksman"),Hero("Granger",3,"Kishin","Marksman"),
Hero("Kagura",4,"Dragon Altar","Stargazer"),Hero("Hanabi",3,"Dragoncaller","Stargazer"),Hero("Lunox",4,"Kishin","Stargazer"),Hero("Cecilion",3,"Enchanted Tales","Stargazer"),Hero("Pharsa",2,"Mistbender","Stargazer"),Hero("Aurora",2,"Astro Power","Stargazer"),
Hero("Ling",4,"Echomancer","Swiftblade"),Hero("Hayabusa",3,"Dragon Altar","Swiftblade"),Hero("Fanny",4,"SPECTRE","Swiftblade"),Hero("Lancelot",3,"Starbelle","Swiftblade"),Hero("Gusion",2,"Kishin","Swiftblade"),Hero("Johnny",2,"Phasewarper","Swiftblade"),
Hero("Eudora",1,"Shadeweaver","Mage"),Hero("Nana",2,"Astro Power","Mage"),Hero("Cyclops",2,"Echomancer","Mage"),Hero("Valir",3,"SPECTRE","Mage"),Hero("Zhuxin",2,"Phasewarper","Mage"),Hero("Lylia",3,"Enchanted Tales","Mage"),
Hero("Diggie",2,"Echomancer","Phasewarper"),Hero("Rafaela",1,"Dragoncaller","Phasewarper"),Hero("Angela",3,"Starbelle","Phasewarper"),Hero("Estes",2,"Kishin","Phasewarper"),
Hero("Lapu-Lapu",3,"Echomancer","Scavenger"),Hero("Alpha",2,"SPECTRE","Scavenger")
)
fun sampleBoard():BoardState=BoardState(
heroes=listOf(Hero("Mathilda",3,"Starbelle","Swiftblade",1,emptyList(),"front"),Hero("Johnny",2,"Phasewarper","Swiftblade",1,emptyList(),"mid"),Hero("Zhuxin",2,"Phasewarper","Mage",1,emptyList(),"back"),Hero("Minotaur",2,"SPECTRE","Defender",1,emptyList(),"front")),
bench=listOf(Hero("Eudora",1,"Shadeweaver","Mage",1,emptyList(),"bench")),
shop=listOf(ShopItem("Roger",3,"SPECTRE","Bruiser"),ShopItem("Barats",1,"Kishin","Dauntless"),ShopItem("Aldous",3,"Kishin","Bruiser"),ShopItem("Terizla",2,"Enchanted Tales","Bruiser"),ShopItem("Fanny",4,"SPECTRE","Swiftblade")),
synergies=listOf(Synergy("Phasewarper",SynergyType.ROLE,2,2,"+20% Attack Speed"),Synergy("Swiftblade",SynergyType.ROLE,2,4,"+15% Crit Rate"),Synergy("Starbelle",SynergyType.FACTION,1,2,"+10% HP"),Synergy("Mage",SynergyType.ROLE,1,2,"+15% Magic Power"),Synergy("SPECTRE",SynergyType.FACTION,1,2,"+10% Defense"),Synergy("Defender",SynergyType.ROLE,1,2,"+15% Armor")),
player=PlayerState(16,100,5,0,30,"I-3",1,3,0),
opponents=listOf(OpponentState("PointZero",100,6,28,"Weapon Master + Starbelle","High"),OpponentState("yoseve",93,5,22,"Echomancer + Kishin","Medium"),OpponentState("Heracles",92,5,30,"Astro Power + Phasewarper","Medium"),OpponentState("asaduaan",61,6,53,"Marksman + Starbelle","Very High"),OpponentState("Ryuuu",91,5,20,"Weapon Master + Scavenger","Medium"),OpponentState("Fanny Ruby",90,5,17,"Mage + Phasewarper","Medium"),OpponentState("RRP",53,6,28,"Swiftblade 4","High"),OpponentState("KONZOLODON",92,5,64,"Starbelle + Swiftblade","Low")))}