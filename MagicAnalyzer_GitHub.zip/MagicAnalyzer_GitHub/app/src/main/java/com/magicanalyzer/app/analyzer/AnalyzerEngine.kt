package com.magicanalyzer.app.analyzer

import android.graphics.Bitmap
import com.magicanalyzer.app.data.model.AnalysisResult
import com.magicanalyzer.app.data.model.BoardState
import com.magicanalyzer.app.data.repository.GameDataRepository
import com.magicanalyzer.app.strategy.StrategyEngine

class AnalyzerEngine(private val repo: GameDataRepository) {

    private val vision = VisionAnalyzer()
    private val strategy = StrategyEngine()

    fun analyzeFromScreenshot(bitmap: Bitmap?): AnalysisResult {
        val detected = bitmap?.let { vision.analyzeBitmap(it) }
        return build(detected ?: MockDataProvider.sampleBoard(), sufficientData = detected != null)
    }

    fun analyzeFromMock(): AnalysisResult = build(MockDataProvider.sampleBoard(), sufficientData = true)

    private fun build(board: BoardState, sufficientData: Boolean): AnalysisResult =
        strategy.analyze(board, sufficientData).also { repo.saveLastAnalysis(it) }
}
