package com.magicanalyzer.app.analyzer
import android.content.Context
import android.graphics.Bitmap
import com.google.gson.Gson
import com.magicanalyzer.app.data.model.AnalysisResult
import com.magicanalyzer.app.data.model.BoardState
import com.magicanalyzer.app.data.repository.GameDataRepository
import com.magicanalyzer.app.strategy.StrategyEngine
class AnalyzerEngine(context: Context) {
    private val vision = VisionAnalyzer(context)
    private val strategy = StrategyEngine()
    private val repo = GameDataRepository(context)
    private val gson = Gson()
    fun analyzeFromScreenshot(bitmap: Bitmap?): AnalysisResult {
        val detected = bitmap?.let { vision.analyzeBitmap(it) }
        val board = detected ?: MockDataProvider.sampleBoard()
        return buildResult(board, detected != null)
    }
    fun analyzeFromMock(): AnalysisResult = buildResult(MockDataProvider.sampleBoard(), true)
    fun analyzeFromManualInput(gold: Int, hp: Int, level: Int, exp: Int, round: Int): AnalysisResult {
        val base = MockDataProvider.sampleBoard()
        val board = base.copy(player = base.player.copy(gold=gold, hp=hp, level=level, exp=exp, round=round))
        return buildResult(board, true)
    }
    private fun buildResult(board: BoardState, sufficient: Boolean): AnalysisResult {
        val r = strategy.analyze(board, sufficient)
        repo.saveLastAnalysis(gson.toJson(r))
        return r
    }
}
