package com.magicanalyzer.app.analyzer
import android.content.Context
import android.graphics.Bitmap
import com.google.gson.Gson
import com.magicanalyzer.app.data.model.*
import com.magicanalyzer.app.data.repository.GameDataRepository
import com.magicanalyzer.app.strategy.StrategyEngine
class AnalyzerEngine(c:Context){
private val v=VisionAnalyzer(c);private val s=StrategyEngine();private val r=GameDataRepository(c);private val g=Gson()
fun analyzeFromScreenshot(b:Bitmap?):AnalysisResult{val d=b?.let{v.analyzeBitmap(it)};val board=d?:MockDataProvider.sampleBoard();return build(board,d!=null)}
fun analyzeFromMock():AnalysisResult=build(MockDataProvider.sampleBoard(),true)
fun analyzeFromManualInput(gold:Int,hp:Int,level:Int,round:String):AnalysisResult{val b=MockDataProvider.sampleBoard();return build(b.copy(player=b.player.copy(gold=gold,hp=hp,level=level,round=round)),true)}
private fun build(b:BoardState,suf:Boolean):AnalysisResult{val r=s.analyze(b,suf);this.r.saveLastAnalysis(g.toJson(r));return r}}