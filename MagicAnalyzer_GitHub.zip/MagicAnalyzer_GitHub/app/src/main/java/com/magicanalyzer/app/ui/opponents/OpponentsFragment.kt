package com.magicanalyzer.app.ui.opponents
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.databinding.FragmentOpponentsBinding
class OpponentsFragment:Fragment(){
private var _b:FragmentOpponentsBinding?=null;private val b get()=_b!!
override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{_b=FragmentOpponentsBinding.inflate(i,c,false);return b.root}
override fun onViewCreated(v:View,s:Bundle?){super.onViewCreated(v,s)
val app=requireActivity().application as MagicApp
val j=app.gameRepo.getLastAnalysis()
if(j.isNullOrBlank()){b.tvEmpty.visibility=View.VISIBLE;return}
b.tvEmpty.visibility=View.GONE}
override fun onDestroyView(){super.onDestroyView();_b=null}}