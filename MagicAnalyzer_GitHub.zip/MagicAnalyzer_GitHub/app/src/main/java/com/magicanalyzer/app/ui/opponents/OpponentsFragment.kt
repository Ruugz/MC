package com.magicanalyzer.app.ui.opponents

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.databinding.FragmentOpponentsBinding

class OpponentsFragment : Fragment() {

    private var _binding: FragmentOpponentsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentOpponentsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as MagicApp
        val result = app.gameRepo.getLastAnalysis()?.takeIf { it.sufficientData }
        val opponents = result?.board?.opponents.orEmpty()

        binding.tvEmpty.isVisible = opponents.isEmpty()
        binding.tvOpponents.isVisible = opponents.isNotEmpty()
        binding.tvOpponents.text = opponents.joinToString("\n\n") {
            "${it.name} — HP ${it.hp} · Lv ${it.level} · Gold ${it.gold}\n${it.composition} (${it.strength})"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
