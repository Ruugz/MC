package com.magicanalyzer.app.ui.opponents
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.R
import com.magicanalyzer.app.databinding.FragmentOpponentsBinding
class OpponentsFragment : Fragment() {
    private var _binding: FragmentOpponentsBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentOpponentsBinding.inflate(inflater, container, false); return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as MagicApp
        val json = app.gameDataRepository.getLastAnalysis()
        if (json.isNullOrBlank()) { binding.tvEmpty.visibility = View.VISIBLE; return }
        binding.tvEmpty.visibility = View.GONE
        val map: Map<String, Any> = Gson().fromJson(json, object : TypeToken<Map<String, Any>>() {}.type)
        @Suppress("UNCHECKED_CAST")
        val board = map["board"] as? Map<String, Any>
        @Suppress("UNCHECKED_CAST")
        val opponents = board?.get("opponents") as? List<Map<String, Any>> ?: emptyList()
        binding.layoutOpponents.removeAllViews()
        opponents.forEach { op ->
            val name = op["name"] as? String ?: "?"
            val hp = (op["hp"] as? Double)?.toInt() ?: 0
            val level = (op["level"] as? Double)?.toInt() ?: 0
            val comp = op["composition"] as? String ?: "-"
            val strength = op["strength"] as? String ?: "-"
            val card = TextView(requireContext()).apply {
                text = "$name\nHP: $hp • Lv $level\n$comp\nKekuatan: $strength"
                setPadding(24,24,24,24); setBackgroundResource(R.drawable.bg_card)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 16 }
                setTextColor(0xFFE6E8EE.toInt())
            }
            binding.layoutOpponents.addView(card)
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
