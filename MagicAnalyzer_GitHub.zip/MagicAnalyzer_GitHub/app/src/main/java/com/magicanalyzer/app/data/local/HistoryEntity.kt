package com.magicanalyzer.app.data.local
import androidx.room.*
@Entity(tableName="history")
data class HistoryEntity(@PrimaryKey(autoGenerate=true)val id:Long=0,val timestamp:Long,val round:String,val gold:Int,val hp:Int,val level:Int,val strengthScore:Int,val bestActionTitle:String,val bestActionDescription:String,val composition:String,val prediction:String,val recommendationsJson:String,val sufficientData:Boolean)