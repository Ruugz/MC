package com.magicanalyzer.app.analyzer

import android.graphics.Bitmap
import com.magicanalyzer.app.data.model.BoardState

/** Belum ada engine pengenalan layar; mengembalikan null = data tidak cukup. */
class VisionAnalyzer {
    fun analyzeBitmap(@Suppress("UNUSED_PARAMETER") bitmap: Bitmap): BoardState? = null
}
