package com.magicanalyzer.app.analyzer
import android.content.Context
import android.graphics.Bitmap
import com.magicanalyzer.app.data.model.BoardState
class VisionAnalyzer(private val context: Context) {
    fun analyzeBitmap(bitmap: Bitmap): BoardState? = null
}
