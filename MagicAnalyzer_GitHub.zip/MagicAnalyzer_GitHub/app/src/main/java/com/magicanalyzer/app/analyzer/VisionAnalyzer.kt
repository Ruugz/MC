package com.magicanalyzer.app.analyzer
import android.content.Context
import android.graphics.Bitmap
import com.magicanalyzer.app.data.model.BoardState
class VisionAnalyzer(c:Context){fun analyzeBitmap(b:Bitmap):BoardState?=null}