package com.magicanalyzer.app.data.local
import android.content.Context
import androidx.room.*
@Database(entities=[HistoryEntity::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
abstract fun historyDao():HistoryDao
companion object{@Volatile private var I:AppDatabase?=null
fun getInstance(c:Context):AppDatabase=I?:synchronized(this){val i=Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"magic.db").fallbackToDestructiveMigration().build();I=i;i}}}