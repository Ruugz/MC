package com.magicanalyzer.app.ui.history
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.data.local.HistoryEntity
import com.magicanalyzer.app.databinding.FragmentHistoryBinding
import com.magicanalyzer.app.databinding.ItemHistoryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
class HistoryFragment : Fragment() {
    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false); return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as MagicApp
        val adapter = HistoryAdapter()
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
        viewLifecycleOwner.lifecycleScope.launch { app.historyRepository.getAll().collectLatest { list ->
            adapter.submit(list); binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }}
        binding.btnClear.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext()).setTitle("Hapus semua history?")
                .setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { app.historyRepository.clear() } }
                .setNegativeButton("Batal", null).show()
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
    class HistoryAdapter : RecyclerView.Adapter<HistoryAdapter.VH>() {
        private val items = mutableListOf<HistoryEntity>()
        fun submit(list: List<HistoryEntity>) { items.clear(); items.addAll(list); notifyDataSetChanged() }
        inner class VH(val b: ItemHistoryBinding) : RecyclerView.ViewHolder(b.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val it = items[position]
            holder.b.tvDate.text = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(it.timestamp))
            holder.b.tvRound.text = "Round ${it.round} • Lv ${it.level} • Gold ${it.gold}"
            holder.b.tvBest.text = it.bestActionTitle
            holder.b.tvComp.text = it.composition
            holder.b.tvStrength.text = "Strength ${it.strengthScore}/100"
        }
    }
}
