package com.magicanalyzer.app.ui.history
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.data.local.HistoryEntity
import com.magicanalyzer.app.databinding.FragmentHistoryBinding
import com.magicanalyzer.app.databinding.ItemHistoryBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
class HistoryFragment:Fragment(){
private var _b:FragmentHistoryBinding?=null;private val b get()=_b!!
override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{_b=FragmentHistoryBinding.inflate(i,c,false);return b.root}
override fun onViewCreated(v:View,s:Bundle?){super.onViewCreated(v,s)
val app=requireActivity().application as MagicApp
val adapter=HistoryAdapter()
b.recycler.layoutManager=LinearLayoutManager(requireContext());b.recycler.adapter=adapter
viewLifecycleOwner.lifecycleScope.launch{app.historyRepo.getAll().collectLatest{list->adapter.submit(list);b.tvEmpty.visibility=if(list.isEmpty())View.VISIBLE else View.GONE}}}
override fun onDestroyView(){super.onDestroyView();_b=null}
class HistoryAdapter:RecyclerView.Adapter<HistoryAdapter.VH>(){
private val items=mutableListOf<HistoryEntity>()
fun submit(l:List<HistoryEntity>){items.clear();items.addAll(l);notifyDataSetChanged()}
inner class VH(val b:ItemHistoryBinding):RecyclerView.ViewHolder(b.root)
override fun onCreateViewHolder(p:ViewGroup,v:Int):VH=VH(ItemHistoryBinding.inflate(LayoutInflater.from(p.context),p,false))
override fun getItemCount():Int=items.size
override fun onBindViewHolder(h:VH,pos:Int){val it=items[pos];h.b.tvDate.text="Round ${it.round}";h.b.tvBest.text=it.bestActionTitle}}}