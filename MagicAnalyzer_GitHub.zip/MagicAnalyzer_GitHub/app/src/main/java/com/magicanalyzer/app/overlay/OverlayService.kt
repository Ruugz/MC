package com.magicanalyzer.app.overlay

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Kerangka service overlay; belum diimplementasikan. */
class OverlayService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
