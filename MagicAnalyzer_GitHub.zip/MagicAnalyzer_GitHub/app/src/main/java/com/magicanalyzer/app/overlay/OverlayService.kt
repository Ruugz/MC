package com.magicanalyzer.app.overlay
import android.app.Notification
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.R
class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); startForeground(NOTIF_ID, buildNotification()); showOverlay()
    }
    private fun buildNotification(): Notification = NotificationCompat.Builder(this, MagicApp.CHANNEL_OVERLAY)
        .setContentTitle("Magic Analyzer").setContentText("Overlay aktif").setSmallIcon(R.drawable.ic_analyzer)
        .setPriority(NotificationCompat.PRIORITY_LOW).build()
    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.layout_overlay, null)
        overlayView?.findViewById<TextView>(R.id.tvOverlayText)?.text = "⭐ Best: Scan di aplikasi untuk rekomendasi"
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 120 }
        windowManager?.addView(overlayView, params)
    }
    override fun onDestroy() { super.onDestroy(); overlayView?.let { windowManager?.removeView(it) } }
    companion object { private const val NOTIF_ID = 1001 }
}
