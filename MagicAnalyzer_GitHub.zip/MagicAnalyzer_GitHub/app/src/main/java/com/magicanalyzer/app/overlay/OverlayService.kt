package com.magicanalyzer.app.overlay
import android.app.Service
import android.content.Intent
import android.os.IBinder
class OverlayService:Service(){override fun onBind(i:Intent?):IBinder?=null}