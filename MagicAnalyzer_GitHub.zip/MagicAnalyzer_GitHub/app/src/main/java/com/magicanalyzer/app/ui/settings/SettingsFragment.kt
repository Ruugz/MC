package com.magicanalyzer.app.ui.settings
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.magicanalyzer.app.MainActivity
import com.magicanalyzer.app.databinding.FragmentSettingsBinding
class SettingsFragment : Fragment() {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false); return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvVersion.text = "Version 1.0.0"
        binding.switchOverlay.setOnCheckedChangeListener { _, checked ->
            val act = activity as? MainActivity ?: return@setOnCheckedChangeListener
            if (checked) act.startOverlay() else act.stopOverlay()
        }
        binding.btnAbout.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext()).setTitle("Magic Analyzer")
                .setMessage("Co-pilot untuk Magic Chess: Go Go.\n\nTIDAK melakukan auto-click, auto-play, bot, memory injection, atau modifikasi file game. Semua rekomendasi bersifat informatif.")
                .setPositiveButton("OK", null).show()
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
