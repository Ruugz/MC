package com.magicanalyzer.app.ui.settings
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.magicanalyzer.app.databinding.FragmentSettingsBinding
class SettingsFragment:Fragment(){
private var _b:FragmentSettingsBinding?=null;private val b get()=_b!!
override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{_b=FragmentSettingsBinding.inflate(i,c,false);return b.root}
override fun onViewCreated(v:View,s:Bundle?){super.onViewCreated(v,s);b.tvVersion.text="v1.0.0"}
override fun onDestroyView(){super.onDestroyView();_b=null}}