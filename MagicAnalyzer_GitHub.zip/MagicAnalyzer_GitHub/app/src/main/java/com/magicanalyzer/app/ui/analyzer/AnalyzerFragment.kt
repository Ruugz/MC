package com.magicanalyzer.app.ui.analyzer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.magicanalyzer.app.MagicApp
import com.magicanalyzer.app.analyzer.AnalyzerEngine
import com.magicanalyzer.app.data.local.HistoryEntity
import com.magicanalyzer.app.data.model.AnalysisResult
import com.magicanalyzer.app.databinding.FragmentAnalyzerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AnalyzerFragment : Fragment() {

    private var _binding: FragmentAnalyzerBinding? = null
    private val binding get() = _binding!!

    private val gson = Gson()
    private lateinit var app: MagicApp
    private lateinit var engine: AnalyzerEngine

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAnalyzerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        app = requireActivity().application as MagicApp
        engine = AnalyzerEngine(app.gameRepo)

        val onClick = View.OnClickListener { runAnalysis() }
        binding.btnScan.setOnClickListener(onClick)
        binding.btnAnalyze.setOnClickListener(onClick)
        binding.btnRefresh.setOnClickListener(onClick)
    }

    private fun runAnalysis() {
        viewLifecycleOwner.lifecycleScope.launch {
            binding.progress.visibility = View.VISIBLE
            val result = withContext(Dispatchers.IO) { engine.analyzeFromMock() }
            binding.progress.visibility = View.GONE
            render(result)
            app.historyRepo.insert(result.toEntity())
        }
    }

    private fun render(r: AnalysisResult) = with(binding) {
        tvRound.text = "Round ${r.board.player.round}"
        tvGold.text = "Gold: ${r.board.player.gold}"
        tvHp.text = "HP: ${r.board.player.hp}"
        tvLevel.text = "Level: ${r.board.player.level}"
        tvStrength.text = "Strength: ${r.strengthScore}/100"
        tvComposition.text = r.compositionAnalysis
        tvPrediction.text = r.prediction
        tvTitle.text = "⭐ ${r.bestAction.title}"
        tvDesc.text = r.bestAction.description
        tvConfidence.text = "Confidence: ${r.bestAction.confidence}%"
    }

    private fun AnalysisResult.toEntity() = HistoryEntity(
        timestamp = timestamp,
        round = board.player.round,
        gold = board.player.gold,
        hp = board.player.hp,
        level = board.player.level,
        strengthScore = strengthScore,
        bestActionTitle = bestAction.title,
        bestActionDescription = bestAction.description,
        composition = compositionAnalysis,
        prediction = prediction,
        recommendationsJson = gson.toJson(recommendations),
        sufficientData = sufficientData
    )

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
