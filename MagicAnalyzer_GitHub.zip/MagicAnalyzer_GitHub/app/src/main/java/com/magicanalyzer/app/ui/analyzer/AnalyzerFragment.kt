package com.magicanalyzer.app.ui.analyzer
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.magicanalyzer.app.MainActivity
import com.magicanalyzer.app.R
import com.magicanalyzer.app.analyzer.AnalyzerEngine
import com.magicanalyzer.app.data.local.HistoryEntity
import com.magicanalyzer.app.databinding.FragmentAnalyzerBinding
import com.magicanalyzer.app.databinding.DialogManualInputBinding
import com.magicanalyzer.app.databinding.ItemRecommendationBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class AnalyzerFragment : Fragment() {
    private var _binding: FragmentAnalyzerBinding? = null
    private val binding get() = _binding!!
    private lateinit var engine: AnalyzerEngine
    private val gson = Gson()
    private val pickImage = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) result.data?.data?.let { handleImageUri(it) }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAnalyzerBinding.inflate(inflater, container, false); return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        engine = AnalyzerEngine(requireContext())
        binding.btnScan.setOnClickListener { runMock() }
        binding.btnAnalyze.setOnClickListener { pickImage.launch(Intent(Intent.ACTION_PICK).apply { type = "image/*" }) }
        binding.btnRefresh.setOnClickListener { runMock() }
        binding.btnManual.setOnClickListener { showManual() }
        binding.btnOverlay.setOnClickListener { (activity as? MainActivity)?.startOverlay() }
    }
    private fun handleImageUri(uri: Uri) {
        lifecycleScope.launch {
            binding.progress.visibility = View.VISIBLE
            val bmp = withContext(Dispatchers.IO) { requireContext().contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
            val result = withContext(Dispatchers.IO) { engine.analyzeFromScreenshot(bmp) }
            binding.progress.visibility = View.GONE
            render(result); saveToHistory(result)
        }
    }
    private fun runMock() {
        lifecycleScope.launch {
            binding.progress.visibility = View.VISIBLE
            val result = withContext(Dispatchers.IO) { engine.analyzeFromMock() }
            binding.progress.visibility = View.GONE
            render(result); saveToHistory(result)
        }
    }
    private fun showManual() {
        val dlg = DialogManualInputBinding.inflate(layoutInflater)
        MaterialAlertDialogBuilder(requireContext()).setTitle("Input Manual").setView(dlg.root)
            .setPositiveButton("Analyze") { _, _ ->
                val g = dlg.etGold.text.toString().toIntOrNull() ?: 0
                val h = dlg.etHp.text.toString().toIntOrNull() ?: 0
                val l = dlg.etLevel.text.toString().toIntOrNull() ?: 1
                val e = dlg.etExp.text.toString().toIntOrNull() ?: 0
                val r = dlg.etRound.text.toString().toIntOrNull() ?: 1
                lifecycleScope.launch { val res = engine.analyzeFromManualInput(g,h,l,e,r); render(res); saveToHistory(res) }
            }.setNegativeButton("Batal", null).show()
    }
    private fun render(result: com.magicanalyzer.app.data.model.AnalysisResult) {
        binding.tvRound.text = "Round ${result.board.player.round}"
        binding.tvGold.text = "Gold: ${result.board.player.gold}"
        binding.tvHp.text = "HP: ${result.board.player.hp}"
        binding.tvLevel.text = "Level: ${result.board.player.level}"
        binding.tvStrength.text = "Strength: ${result.strengthScore}/100"
        binding.tvComposition.text = result.compositionAnalysis
        binding.tvPrediction.text = result.prediction
        binding.cardBest.tvTitle.text = "⭐ ${result.bestAction.title}"
        binding.cardBest.tvDesc.text = result.bestAction.description
        binding.cardBest.tvReason.text = "Alasan: ${result.bestAction.reason}"
        binding.cardBest.tvRisk.text = "Risiko: ${result.bestAction.risk}"
        binding.cardBest.tvConfidence.text = "Confidence: ${result.bestAction.confidence}%"
        binding.cardBest.tvAlternatives.text = "Alternatif: ${result.bestAction.alternatives.joinToString(", ")}"
        binding.layoutRecs.removeAllViews()
        binding.tvDataStatus.visibility = if (!result.sufficientData) View.VISIBLE else View.GONE
        if (!result.sufficientData) binding.tvDataStatus.text = "⚠️ Data tidak cukup"
        result.recommendations.forEach { rec ->
            val item = ItemRecommendationBinding.inflate(layoutInflater, binding.layoutRecs, true)
            item.tvTitle.text = rec.title; item.tvDesc.text = rec.description
            item.tvMeta.text = "${rec.type.name} • ${rec.confidence}% • ${rec.risk}"
        }
        Toast.makeText(requireContext(), "Analisis selesai", Toast.LENGTH_SHORT).show()
    }
    private fun saveToHistory(result: com.magicanalyzer.app.data.model.AnalysisResult) {
        lifecycleScope.launch {
            val app = requireActivity().application as com.magicanalyzer.app.MagicApp
            app.historyRepository.insert(HistoryEntity(
                timestamp = result.timestamp, round = result.board.player.round, gold = result.board.player.gold,
                hp = result.board.player.hp, level = result.board.player.level, strengthScore = result.strengthScore,
                bestActionTitle = result.bestAction.title, bestActionDescription = result.bestAction.description,
                composition = result.compositionAnalysis, prediction = result.prediction,
                recommendationsJson = gson.toJson(result.recommendations), sufficientData = result.sufficientData
            ))
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
