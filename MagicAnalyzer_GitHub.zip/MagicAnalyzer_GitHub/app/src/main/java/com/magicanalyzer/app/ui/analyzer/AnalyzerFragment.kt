package com.magicanalyzer.app.ui.analyzer
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.magicanalyzer.app.R
import com.magicanalyzer.app.analyzer.AnalyzerEngine
import com.magicanalyzer.app.data.local.HistoryEntity
import com.magicanalyzer.app.databinding.FragmentAnalyzerBinding
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class AnalyzerFragment:Fragment(){
private var _b:FragmentAnalyzerBinding?=null;private val b get()=_b!!
private lateinit var e:AnalyzerEngine;private val g=Gson()
override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{_b=FragmentAnalyzerBinding.inflate(i,c,false);return b.root}
override fun onViewCreated(v:View,s:Bundle?){super.onViewCreated(v,s);e=AnalyzerEngine(requireContext())
b.btnScan.setOnClickListener{runMock()};b.btnAnalyze.setOnClickListener{runMock()};b.btnRefresh.setOnClickListener{runMock()}}
private fun runMock(){lifecycleScope.launch{b.progress.visibility=View.VISIBLE
val r=withContext(Dispatchers.IO){e.analyzeFromMock()}
b.progress.visibility=View.GONE
b.tvRound.text="Round ${r.board.player.round}";b.tvGold.text="Gold: ${r.board.player.gold}"
b.tvHp.text="HP: ${r.board.player.hp}";b.tvLevel.text="Level: ${r.board.player.level}"
b.tvStrength.text="Strength: ${r.strengthScore}/100";b.tvComposition.text=r.compositionAnalysis;b.tvPrediction.text=r.prediction
b.cardBest.tvTitle.text="⭐ ${r.bestAction.title}";b.cardBest.tvDesc.text=r.bestAction.description
b.cardBest.tvConfidence.text="Confidence: ${r.bestAction.confidence}%"
save(r)}}
private fun save(r:com.magicanalyzer.app.data.model.AnalysisResult){lifecycleScope.launch{
val app=requireActivity().application as com.magicanalyzer.app.MagicApp
app.historyRepo.insert(HistoryEntity(timestamp=r.timestamp,round=r.board.player.round,gold=r.board.player.gold,hp=r.board.player.hp,level=r.board.player.level,strengthScore=r.strengthScore,bestActionTitle=r.bestAction.title,bestActionDescription=r.bestAction.description,composition=r.compositionAnalysis,prediction=r.prediction,recommendationsJson=g.toJson(r.recommendations),sufficientData=r.sufficientData))}}
override fun onDestroyView(){super.onDestroyView();_b=null}}